<?php include_once('header.php'); ?>

<?php include_once('config.php'); ?>

<div class="container">

	<h4>Purchase Order</h4>

	<table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">PID</th>
      <th scope="col">Supplier</th>
      <th scope="col">EDIT</th>
      <th scope="col">DELETE</th>
    
    </tr>
  </thead>
  <tbody>
  <?php 
  	get_supplier_2nd();
  ?>
  </tbody>
</table>
</div>

<?php include_once('footer.php'); ?>

