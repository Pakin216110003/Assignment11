<?php include_once('header.php'); ?>

<?php include_once('config.php'); ?>
<?php  get_supplier_value(); ?>
<div class="container">

	<h4>EDIT</h4>


<form method="POST">
  <div class="form-group">
    <label for="text">Supplier</label>
    <input type="text" class="form-control"  name="supplier">
    
  </div>
  
  <button type="submit" class="btn btn-primary" name="edit">EDIT</button>
</form>

</div>


<?php include_once('footer.php'); ?>

