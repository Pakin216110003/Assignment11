<?php   


function redirect($location){  //redirect to some location
    header("Location: $location"); 
}




function query($sql){
  global $link;
    return mysqli_query($link, $sql);

}


function confirm($retval){ // show what is the error of the code. to avoid query errors
    global $link;
     if(!$retval){
        die("QUERY FAILED". mysqli_error($link));   
             }
}




function fetch_array($retval){ //fetch. get info from db

    return mysqli_fetch_array($retval);
}



/////////////////////////Function start////////////////////////

/////////////////////////Get supplier name////////////////////////


function get_supplier(){

$sql = query("SELECT * from supplier order by sid ASC");
   				confirm($sql);
                   while($row = fetch_array($sql)){ 
                       echo "<option>{$row['supplier']}</option>";
                       
                   }
   				}




/////////////////////////get purchase orders////////////////////////
function get_purchase(){

    $sql = query("SELECT * from purchase_orders order by pid ASC"); 
    confirm($sql); 
    while($row = fetch_array($sql)){ 
$product = <<<DELIMETER


<tr>
<th scope='row'>{$row['pid']}</th>
<td>{$row['supplier']}</td>
<td>{$row['purchase_order_date']}</td>
<td>{$row['product']}</td>
<td>{$row['description']}</td>
<td>{$row['qty']}</td>
<td>{$row['unit_cost']}</td>
</tr>


DELIMETER;

echo $product;
    }
}



/////////////////////////Insert order/////////////////////////////
function insert_order(){
if(isset($_POST['Submit'])){

    $supplier = $_POST['supplier'];
    $shipping =  $_POST['shipping'];
    $date =  $_POST['purchasedate'];
    $prod =  $_POST['product'];
    $desc =  $_POST['desc'];
    $qty = $_POST['qty'];
    $cost =  $_POST['cost'];


    if((!empty($_POST['supplier'])) &&(!empty($_POST['shipping'])) &&(!empty( $_POST['purchasedate'])) &&(!empty($_POST['product'])) &&(!empty($_POST['desc'])) &&(!empty($_POST['qty'])) &&(!empty($_POST['cost']))){
 
    
    //insert stuff
    
    for ($i=0; $i < count($prod); $i++) { 
        $sql = query("INSERT INTO purchase_orders (supplier,shipping_addr, purchase_order_date, 
                   product, description, qty, unit_cost) VALUES('$supplier','$shipping','$date', '$prod[$i]', '$desc[$i]', '$qty[$i]', $cost[$i])");
                confirm($sql); 
             
    }
    
    }
    
}
redirect("po.php");

    }



    /////////////////////////show supplier////////////////////////
function get_supplier_2nd(){

    $sql = query("SELECT * from supplier order by sid ASC"); 
    confirm($sql); 
    while($row = fetch_array($sql)){ 
$product = <<<DELIMETER


<tr>
<th scope='row'>{$row['sid']}</th>
<td>{$row['supplier']}</td>
<td>  <a href="edit_supplier.php?id={$row['sid']}"><button type="button" class="btn btn-secondary"> <i class="fas fa-edit"></i> </button></a> </td>
<td> <a href="delete_supplier.php?id={$row['sid']}"><button type="button" class="btn btn-danger"> <i class="fas fa-trash-alt"></i> </button></a> </td>
</tr>


DELIMETER;

echo $product;
    }
}



    /////////////////////////get supplier value////////////////////////
    function get_supplier_value(){
if(isset($_POST['edit'])){
 $supplier = $_POST["supplier"];

        $sql = query("UPDATE supplier SET supplier = '{$supplier}' WHERE sid =" . $_GET['id'] . "");
        confirm($sql); 
        redirect("Supplier.php");
    }
    
    }
?>