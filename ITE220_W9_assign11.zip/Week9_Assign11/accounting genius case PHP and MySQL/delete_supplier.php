<?php  require_once("config.php"); ?>
<?php
if(isset($_GET['id'])){


$sql = query("DELETE FROM supplier WHERE sid = " .$_GET['id'] . "");
confirm($sql);



redirect("Supplier.php");


}else{
    redirect("Supplier.php");
}
?>